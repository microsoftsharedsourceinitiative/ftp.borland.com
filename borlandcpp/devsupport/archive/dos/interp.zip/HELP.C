#include <mem.h>
#include <stdlib.h>
#include "externs.h"

/**** help function ****/

int help(int argc,char *argv[])
{
 char *underline;

 if (argc==1)  /* check if only command enter w/0 arguments  */
 {
  int index=0;
  int size;

  printf("\nHELP MENU ALL  COMMANDS\n");   /* print title */
  printf("=======================\n\n");

  while (htable[index].name)              /* print all help records */
  {
   size=strlen(htable[index].name)+1;

   printf("%s",htable[index].name);  /* print command name */

   underline=(char *)malloc(size+1);  /* make underline for command */
   memset(underline,'-',size);        /* name that matches          */
   *(underline+size)=NULL;

   printf("\n%s\n",underline);        /* print underline */
   
   printf("%s\n\n",htable[index].descrip);  /* print descriptions */
   index++;

   if( !(index%4))
   {
	printf("hit any key to coninue");
	getche();
	printf("\n\n");
   }

  }
  free(underline);
 }
 else
 {
  int index=0;
  int not_equal;
  while((not_equal=strcmp(argv[1],htable[index].name)) &&
	htable[index].name)
   index++;

  if (not_equal)
   error(etable[7]);
  else
   printf("\nCOMMAND:\n-------\n%s\n\nDESCRIPTION:\n------------\n%s\n",
          htable[index].name,htable[index].descrip);
 }

 return 0;
}



