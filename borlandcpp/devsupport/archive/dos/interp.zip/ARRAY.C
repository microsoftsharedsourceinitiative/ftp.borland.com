


char huge name[67000];

void main(void)
{ }
