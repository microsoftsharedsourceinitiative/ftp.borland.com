#include <stdio.h>
#include "externs.h"

/**********************************/
/*                                */
/*    globals  file               */
/*                                */
/**********************************/

//unsigned _ovrsize =  160;
//unsigned _ovrbufer = 160;

char  *cmd_line;            /* command line entered from interpeter */

struct stu *start=NULL;     /* intialize link list of students */

struct dispatch_table       /* function dispatch table  */

 table[DISPATCH_TABLE_SIZE]=      /* w/ search name and funtion pointer */
 { "help",help,
   "addemup",addemup,
   "view",view,
   "add_student",add_student,
   "add",add_student,
   "show_students",show_students,
   "show",show_students,
   "find",find,
   "delete_student",delete_student,
   "del",delete_student,
    NULL,NULL};

struct error_table
 etable[ERROR_TABLE_SIZE]=
 {
  "file not found\n",0,                               /*  0 */
  "invalid parameters\n",0,                           /*  1 */
  "invalid command\n",0,                              /*  2 */
  "exit real time interpeter\n",1,                    /*  3 */
  "file not opened\n",0,                              /*  4 */
  "no filename specified\n",0,                        /*  5 */
  "no parameters passed\n",0,                         /*  6 */
  "help does not exist for invalid command\n",0,      /*  7 */
  "to many arguments used with command\n",0,          /*  8 */
  "to few arguments used with this command\n",0,      /*  9 */
  "out of memory could not complete operation\n",0,   /* 10 */
  "student identifcation number not unique\n",0,      /* 11 */
  "student list is emtpy\n",0,                        /* 12 */
  "student name not found\n",0,                       /* 13 */
  "student id not found\n",0,                         /* 14 */
  "student name/id combination not found\n",0 };      /* 15 */

struct help_table

htable[HELP_TABLE_SIZE]=
 {
  "help","help alone displays all commands,\nhelp <name> displays help for <name>",

  "view","view <filename> where filename is\na file to view to screen",

  "addemup","addemup <n1> <n2> <n3> <n...>\nadd up to 20 integers specified",

  "exit","to exit the real time interpeter",

  "add_student","add_student <name> <id>\nadd a student to database\nabreviated command 'add'",

  "add","short command for add student",

  "show_students","show all students in list\nshow_students '-' for reverse sort order\nabreviated command 'show'",

  "show","short command for show_student",

  "find","find a student record by id  or name\nfind 'student' or 'id' <parameter>",

  "find student","find student record by name\nfind student <name>",

  "find id","find student by identification number\nfind id <id>",

  "delete_student","delete a student from the list specified by id and name\ndelete_student <name> <id>\nabreviatied command 'del'",

   NULL,NULL};

