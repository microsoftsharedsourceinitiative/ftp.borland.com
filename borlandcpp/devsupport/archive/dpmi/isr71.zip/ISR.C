#include	<dos.h>
#include	<stdio.h>
#include <conio.h>

#undef outp
#undef inp
#undef outportb
#undef inportb

#define outp(a,b) outportb(a,b)
#define inp(a) inportb(a)

#define INTR 0x71

typedef struct
{
  unsigned long	off;
  unsigned short sel;
} Vector;

Vector oldhandler;

void newhandler (void);
void Beep( int frequency, int duration );

int	count	= 0;
unsigned short MyDS;

#ifdef	__DPMI32__
Vector getvect( int intr )
{
	Vector retval;
  static unsigned long o;
  static unsigned short s;

    _AX = 0x0204;           // DPMI get p.m. vector
		_BL = intr;
    geninterrupt (0x31);
    s = _CX;
    o = _EDX;

	  retval.off = o;
	  retval.sel = s;

	return	retval;
}

void	setvect( int intr, Vector addr )
{
  static unsigned long o;
  static unsigned short s;

  s = addr.sel;
  o = addr.off;

  _AX  = 0x0205;          // DPMI set p.m. vector
  _BL  = intr;
  _CX  = s;
  _EDX = o;
  geninterrupt (0x31);
}
#endif

void cHandler (void)
{
  Beep (2000,10);
//  inportb (0x61);
}

int	main( void )
{
  Vector vec;
  char c = 0;

  Beep (1000, 300);

  vec.off = (unsigned long)newhandler;
  vec.sel = _CS;
  MyDS = _DS;

	oldhandler	= getvect( INTR );
	setvect( INTR, vec );

  #if INTR != 0x9
    geninterrupt (INTR);
  #endif


  printf ("Press some keys, or <Esc> to exit\n");

	while( c != 27)
  {
    c = getch ();
    if (c == 0)
    {
  	  printf( "<%02X>    ",getch());
    }
  	else
  	  printf( " %02X     ",c );
  }


	setvect( INTR, oldhandler );

  printf ("\nTotal count = %d\n", count);

	return 0;
}
void Beep( int frequency, int duration )
{
    int control;
    unsigned long i;

    /* If frequency is 0, Beep doesn't try to make a sound. It
     * just sleeps for the duration.
     */
    if( frequency )
    {
        /* 75 is about the shortest reliable duration of a sound. */
	if( duration < 75 )
            duration = 75;

        /* Prepare timer by sending 10111100 to port 43. */
	outp( 0x43, 0xb6 );

        /* Divide input frequency by timer ticks per second and
         * write (byte by byte) to timer.
         */
        frequency = (unsigned)(1193180L / frequency);
        outp( 0x42, (char)frequency );
	outp( 0x42, (char)(frequency >> 8) );

	/* Save speaker control byte. */
	control = inp( 0x61 );

	/* Turn on the speaker (with bits 0 and 1). */
	outp( 0x61, control | 0x3 );
    }

    for (i=0;i<1000*duration;i++);
  //  delay( duration );

    /* Turn speaker back on if necessary. */
    if( frequency )
	outp( 0x61, control );

}
