#include <windows.h>
#include	<stdio.h>
#include	<dos.h>

#ifndef INTNUM
  #define INTNUM 0x21
#endif

#include	"int32.h"

typedef	unsigned long	uint32;
typedef void  (*vfp) (void);

unsigned short fooDS;

typedef struct	VectRegs
{
	uint32	ebp;
	uint32	edi;
	uint32	esi;
	uint32	 ds;
	uint32	 es;
	uint32	edx;
	uint32	ecx;
	uint32	ebx;
	uint32	eax;
	uint32	eip;
	uint32	 cs;
	uint32	flags;
}	VectRegs;

VectRegs regs [1000];


void goober (int x)
{
  x++;
  MessageBeep (1);
}

#pragma argsused
int cdecl foo (uint32	ebp,
	       uint32	edi,
	       uint32	esi,
	       uint32	 ds,
	       uint32	 es,
	       uint32	edx,
	       uint32	ecx,
	       uint32	ebx,
	       uint32	eax,
	       uint32	eip,
	       uint32	 cs,
	       uint32	flags)
{
  goober (1);
	return 1;
}

void main (void)
{
	static vfp		thunk;
	static int		i;
	static union	REGS	inregs;
	static unsigned short	oldVectCS;
	static unsigned long	oldVectEIP;

	fooDS = _DS;

  printf ("Starting test...\n");

#ifndef CALL_DIRECT

	inregs.x.eax	= 0x204;
	inregs.x.ebx	= INTNUM;
	int386 (0x31, &inregs, &inregs);   // get the old vector
	oldVectCS		= (unsigned short)inregs.x.ecx;
	oldVectEIP	= 		  inregs.x.edx;

#ifdef DONT_CHAIN
  thunk = _makeInt32Thunk (foo, &fooDS, 0,0);   // This causes an iret
#else
  thunk = _makeInt32Thunk (foo, &fooDS, oldVectCS, oldVectEIP); // This causes
                                                            // a chain to the
                                                            // old vector
#endif

	inregs.x.eax	= 0x205;
	inregs.x.ebx	= INTNUM;
	inregs.x.ecx	= _CS;
	inregs.x.edx	= (uint32) thunk;
	int386 (0x31, &inregs, &inregs);   // hook the new vector

#if (INTNUM == 0x21)
  printf ("printf\n");
#else
  asm int INTNUM;
#endif

	inregs.x.eax	= 0x205;
	inregs.x.ebx	= INTNUM;
	inregs.x.ecx	= oldVectCS;
	inregs.x.edx	= oldVectEIP;
	int386 (0x31, &inregs, &inregs);  // unhook the new vector
#else
  thunk = _makeInt32Thunk (foo, &fooDS, 0, 0);  // this causes an IRET

  // Here we simulate a call to the interrupt via the thunk.
  asm pushfd
  asm push cs
  thunk ();

#endif
	printf ("\nDone.\n\n");
}

