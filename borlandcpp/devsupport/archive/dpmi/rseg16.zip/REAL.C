#pragma option -k-              /* turn off standard stack frame */
#pragma option -Od              /* no opts */

#include <dos.h>
#include "real.h"

/* the function below should never be called,
 * it is used ONLY because we need to store 
 * something in our code/text segment, and
 * use of assembly is not part of the spec
 */
static void dummy(void)
{
    return;
}

#define STORED_SEG (* (unsigned short *) dummy)

/* argument is passed in AX */
void stash_seg_Real(void)
{
        unsigned short seg = _AX;
        STORED_SEG = seg;
}

void __interrupt do_it_Real()
{
        unsigned short ax = _AX;      /* in case AX is used in calc. below */
	unsigned short *block = MK_FP(STORED_SEG, 0);

	*block = ax;
}
