
#include <stdio.h>
#include "externs.h"



/**** error function ****/

int error(struct error_table entry)
{
 int c;

 printf("%s",entry.message);

 if (entry.fatal)
  exit(0);

 do
 {
  printf("\nDo you wish to display entire help menu(Y/N)? ");
  c=toupper(getchar());
 } while  (c!='Y' && c!='N');


 printf("\n");

 if (c=='Y')
  help(1,NULL);

 return 0;
}
