/*--------------------------------------------------------------------------*/
/*                                                                          */
/* MOUSE.C - Example of how to use the mouse in a BGI graphics program      */
/*           under DOS, DPMI16 and DPMI32.  This example shows how to set   */
/*           up a mouse callback handler, set the graphics mouse shape,     */
/*           get keyboard input in graphics mode, save a graphics image     */
/*           to a file, and load a graphics image from a file, in all       */
/*           three modes (DOS, DPMI16, DPMI32).                             */
/*                                                                          */
/*           Copyright (c) 1994 by Borland International                    */
/*           All Rights Reserved.                                           */
/*                                                                          */
/*           This program will allow you to draw on the screen with the     */
/*           left mouse button, erase with the right one, save an image     */
/*           with the 'S' key, load an image with the 'L' key, clear the    */
/*           screen with the 'C' key, and change the mouse pointer shape    */
/*           with the <SPACE> key.  <ESCAPE> exits the program.             */
/*                                                                          */
/*--------------------------------------------------------------------------*/

#include <stdlib.h>
#include <dos.h>
#include <stdio.h>
#include <conio.h>
#include <alloc.h>
#include <process.h>
#include <graphics.h>

#define MOUSE    0x33
#define DPMI     0x31
#define UPPER    0x0000
#define LEFT     0x0000
#define LOWER    0x0010
#define RIGHT    0x0010
#define MIDDLE   0x0008
#define FNAMELEN 80
#define INFOLEN  80

//  The following are also used in mousea.asm
int x, y, L, R;
void setHandler ( void );

typedef unsigned short ushort;
typedef unsigned long  ulong;

const int mheight = 16;
int exHeight;

#ifdef __DPMI32__

// Global vars to be used with DPMI32
static ushort DosMemSeg = 0, DosMemSel = 0;

// structure of real mode register
struct reg
{
  ulong di;
  ulong si;
  ulong bp;
  ulong res;
  ulong bx;
  ulong dx;
  ulong cx;
  ulong ax;
  ushort cpustat;
  ushort es;
  ushort ds;
  ushort fs;
  ushort gs;
  ushort ip;
  ushort cs;
  ushort sp;
  ushort ss;
};
struct reg mreg;
#endif

// structure for the mouse shape
struct shape
{
  ushort and[16];
  ushort xor[16];
};

struct shape plus =
{
  { 0 },
  {
    0x0180, 0x0180, 0x0180, 0x0180,
    0x0180, 0x0180, 0x0180, 0xFFFF,
    0xFFFF, 0x0180, 0x0180, 0x0180,
    0x0180, 0x0180, 0x0180, 0x0180
  }
};

struct shape square =
{
  { 0 },
  {
    0xFFFF, 0x8001, 0x8001, 0x8001,
    0x8001, 0x8001, 0x8001, 0x8001,
    0x8001, 0x8001, 0x8001, 0x8001,
    0x8001, 0x8001, 0x8001, 0xFFFF
  }
};

struct shape downarrow =
{
  { 0 },
  {
    0xC000, 0xE000, 0x7000, 0x3800,
    0x1C00, 0x0E01, 0x0703, 0x0387,
    0x01CF, 0x00FF, 0x007F, 0x007F,
    0x00FF, 0x01FF, 0x03FF, 0x07FF
  }
};

struct shape uparrow =
{
  { 0 },
  {
    0xFFE0, 0xFFC0, 0xFF80, 0xFF00,
    0xFE00, 0xFE00, 0xFF00, 0xF380,
    0xE1C0, 0xC0E0, 0x8070, 0x0038,
    0x001C, 0x000E, 0x0007, 0x0003
  }
};

#ifdef __DPMI32__
// allocate 64 bytes of DOS memory block for the shapes to reside in
void allocDOSmem (void)
{
  _AX = 0x0100;
  _BX = 64 / 16;           // means four paragraphs's
  geninterrupt ( DPMI );
  DosMemSeg = _AX;         // the real mode segment
  DosMemSel = _DX;         // the prot mode selector
}

// free DOS memory block
void freeDOSmem (void)
{
  if (DosMemSel != 0)
  {
    _AX = 0x0101;
    _DX = DosMemSel;
    geninterrupt (DPMI);
  }
}
#endif

// initialize the data for the mouse pointer struct
void initshape ( struct shape *minnie )
{
  int i;

  // This sets the and mask to the bitwise inverse of the xor mask
  // for the mouse shape

  for ( i = 0; i < 16; i++ )
    minnie->and[i] = (ushort)(~minnie->xor[i]);
}

int ResetMouse ( void )
{
  _AX = 0x0000;
  geninterrupt ( MOUSE );
  return( _AX );
}

void ShowMouse ( void )
{
  _AX = 0x0001;
  geninterrupt ( MOUSE );
}

void HideMouse ( void )
{
  _AX = 0x0002;
  geninterrupt ( MOUSE );
}

void SetMousePos ( int x, int y )
{
  _AX = 0x0004;
  _CX =(ushort) x;
  _DX =(ushort) y;
  geninterrupt ( MOUSE );
}

void VertLimit ( void )
{
  _AX = 0x0008;
  _CX = 25;
  _DX = 479;
  geninterrupt ( MOUSE );
}

//  Set the mouse pointer shape, with the hot spot location passed in
void SetShape (struct shape *mshape, ushort leftoff, ushort topoff)
{
#ifdef __DPMI32__
//mshape has 64 bytes and is being copied one dword (4 bytes) at a time
  asm {
    mov esi, mshape
    mov es, DosMemSel
    mov edi, 0
    mov ecx, 64
    rep movsb
  }

  _BL = 0x0033;         // interrupt 33h for the mouse
  _BH = 0x0000;
  _CX = 0x0000;
  _ES = _DS;
  _EDI = (long)&mreg;
  mreg.ax = 0x0009;     // MOUSE function 9h to set the pointer shape
  mreg.bx = leftoff;
  mreg.cx = topoff;
  mreg.es = DosMemSeg;
  mreg.dx = 0x0000;
  _AX = 0x0300;         // DPMI Simulate real mode interrupt
  geninterrupt ( DPMI );
#else
  _AX = 0x0009;         // MOUSE function 9h to set the pointer shape
  _BX = leftoff;
  _CX = topoff;
  _ES = FP_SEG (mshape);
  _DX = FP_OFF (mshape);
  geninterrupt (MOUSE); // interrupt 33h for the mouse
#endif
}

// initialize the BGI graphics interface
void bgiinit ( void )
{
  int grdrv, grmode;

  grdrv = DETECT;
  initgraph ( &grdrv, &grmode, getenv("BGI") ? getenv("BGI"): "");
  if ( graphresult () != grOk )
  {
    printf ( "\n\nInitGraph Error - EGAVGA.BGI not in current dir...\n" );
    printf ( "\nSet the environment variable BGI= to the path to your BGI directory:\n" );
    printf ( "  SET BGI=c:\\bc4\\bgi \n" );
    exit (0);
  }
  setcolor ( WHITE );
  setbkcolor ( BLACK );
}

// initialize the mouse
void mouseinit ( void )
{
  if ( !ResetMouse () )
  {
    closegraph();
    printf ("\n\nNo mouse driver installed !!\n");
    exit (0);
  }
  ShowMouse ();
  setHandler ();
  VertLimit ();
  initshape ( &plus );
  initshape ( &square );
  initshape ( &downarrow );
  initshape ( &uparrow );
}

// read a string from the keyboard and display it on the graphics screen
void GetInString (int x, int y, char *instring, int max)
{
  int index = 0;
  char inchar;

  inchar =(char) getch ();
  while ( !(inchar == 13 || inchar == 10) )   // test for CR and LF
  {
    if ( inchar == 0 )                        // get rid of leading 0's
      getch ();
    else
    {
      if ( inchar == 8 )                      // BACKSPACE
      {
        if (index)
        {
          setfillstyle (SOLID_FILL, BLACK);
          bar (x, y, x+textwidth (instring),  // blank the input status line
                    y+textheight (instring));
          --index;
          instring[index] = 0;
          outtextxy ( x, y, instring );
        }
      }
      else
      {
        if (index < max)
        {
          instring[index] = inchar;
          ++index;
          instring[index] = 0;
          outtextxy ( x, y, instring );
        }
      }
    }
	 inchar =(char) getch ();
  }
  instring[index] = 0;
}

// save the screen image to a file
void saveImage (char *flname)
{
  int ybegin = exHeight+mheight+1, yend, yincr;
  int xbegin = 0, xend, chunk;
  unsigned size ;
  FILE *fp;
  void far *buff;

  yend = getmaxy ();
  xend = getmaxx ();
  yincr = (yend - ybegin) / 3;                // divide screen into 3 chunks
  size = imagesize (xbegin, ybegin, xend,     // get byte size of chunk
         (ybegin + yincr));
  fp = fopen (flname, "wb");
  buff = farmalloc (size);                    // allocate temp buff,
                                              // sizeof chunk
  if (!buff)
  {
    closegraph();
    printf ("Error Allocation memory\n");
    exit (-1);
  }
  for (chunk = 0; chunk < 3; chunk++)
  {
    getimage (xbegin, (ybegin + (yincr * chunk)), xend,
              (ybegin + (yincr * (chunk + 1))), buff);
    fwrite (buff, size, 1, fp);
  }
  farfree (buff);
  fclose (fp);
}

// load an image from file to screen
void loadImage (char *flname)
{
  int ybegin = exHeight+mheight+1, yend, yincr;
  int xbegin = 0, xend, chunk;
  unsigned size ;
  FILE *fp;
  void far *buff;

  yend = getmaxy ();
  xend = getmaxx ();
  yincr = (yend - ybegin) / 3;                // divide screen into 3 chunks
  size = imagesize (xbegin, ybegin, xend,     // get byte size of chunk
         (ybegin + yincr));
  fp = fopen (flname, "rb");
  buff = farmalloc (size);                    // allocate temp buff,
                                              // sizeof chunk
  if (!buff)
  {
    closegraph();
    printf ("Error Allocation memory\n");
    exit (-1);
  }
  for (chunk = 0; chunk < 3; chunk++)
  {
    fread (buff, size, 1, fp);
    putimage (xbegin, (ybegin + (yincr * chunk)), buff, COPY_PUT);
  }
  farfree (buff);
  fclose (fp);
}

void EraseString (char *s)
{
  setfillstyle (SOLID_FILL, BLACK);
  bar (0, 0, textwidth (s), textheight (s));  // blank the string
}

#pragma argsused
int main (int argc, char *argv[])
{
  int xchar = 0, ychar = 0, newl = 0, newr = 0;
  char str[INFOLEN] = "", filename[FNAMELEN] = "";
  int tempx = 0, tempy = 0, tempL = 0, tempR = 0;
  int out = 0, counter = 0;
  char *inputprompt;
  char inp;

  clrscr ();
  bgiinit ();
  mouseinit ();
  exHeight = textheight (str);

#ifdef __DPMI32__
  allocDOSmem ();
#endif

  while (!out)
  {
    xchar = x;
    ychar = y;
    newl = L;
    newr = R;

    if (((xchar != tempx) || (ychar != tempy) || (newl != tempL) || (newr != tempR)))
    {
      EraseString (str);
      if ((newl == 1) && (newr != 1) && (tempx != 0) && (tempy != 0))
      {
        HideMouse ();
        line (xchar, ychar, tempx, tempy);
        ShowMouse ();
      }
      if ((newr == 1) && (newl != 1))
      {
        setcolor (getbkcolor ());
        HideMouse ();
        line (xchar, ychar, tempx, tempy);
        ShowMouse ();
        setcolor (WHITE);
      }
    }
    sprintf (str, "( %03d, %03d ) Left: %1d  Right: %1d  ", xchar, ychar, newl, newr);
    outtextxy (1, 1, str);
    tempx = xchar;
    tempy = ychar;
    tempL = newl;
    tempR = newr;
    if (kbhit())
    {
      inp =(char) getch ();
      switch (inp)
      {
        case 27:            // <Esc>
          out = 1;
          break;

        case 'c':           // Clear the screen
            HideMouse ();
            cleardevice ();
            mouseinit ();   // This resets the mouse cursor shape and position
                            // back to the defaults.
            x = 0;
            y = 0;
            tempx = 0;
            tempy = 0;
            break;

        case 'l':           // Load a graphics image from a file
          HideMouse ();
          EraseString (str);
          inputprompt = "Enter filename to load: ";
          outtextxy (1, 1, inputprompt);
          GetInString (textwidth(inputprompt), 1, filename, FNAMELEN);
          loadImage (filename);
          ShowMouse ();
          setfillstyle (SOLID_FILL, BLACK);
          bar (0, 0, (textwidth (str) + textwidth (inputprompt)),
                     textheight (str));          // blank the status line
          break;

        case 's':
          HideMouse ();
          EraseString (str);
          inputprompt = "Enter filename to save: ";
          outtextxy (1, 1, inputprompt);
          GetInString (textwidth(inputprompt), 1, filename, FNAMELEN);
          saveImage (filename);
          ShowMouse ();
          setfillstyle (SOLID_FILL, BLACK);
          bar (0, 0, (textwidth (str) + textwidth (inputprompt)),
                     textheight (str));         // blank the status line
          break;

        case ' ':
          switch (counter)
          {
            case 0:
              SetShape (&plus, MIDDLE, MIDDLE);
              counter++;
              break;

            case 1:
              SetShape (&square, LEFT, UPPER);
              counter++;
              break;

            case 2:
              SetShape (&downarrow, RIGHT, LOWER);
              counter++;
              break;

            case 3:
              SetShape (&uparrow, LEFT, UPPER);
              counter = 0;
              break;

            default:
              break;
          }
          break;
      }
    }
  }

#ifdef __DPMI32__
  freeDOSmem ();
#endif
  HideMouse ();
  closegraph ();
  return 0;
}

