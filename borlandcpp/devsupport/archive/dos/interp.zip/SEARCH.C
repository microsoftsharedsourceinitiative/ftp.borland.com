

#include <string.h>


#include "externs.h"

/************************************************************/
/*                                                          */
/* search function.  function to search function pointer    */
/* table for a specific function and return a pointer       */
/* to that function for calling                             */
/*                                                          */
/************************************************************/





FP search(command)
char *command;
{
 int index=0;
			      /* check for end of table */
 while(table[index].function_name!=NULL)
 {
  if (!strcmp(table[index].function_name,command)) /* check for function */
   break;                                          /* found in table     */

  index++;   /* check next table entry */
 }


 return table[index].function_pointer;   /* return function pointer */

}
