Borland TurboVision 2.0

NOTE ON THE CONTENTS OF THIS ARCHIVE:
-------------------------------------
The three enclosed .ZIP files comprise all necessary and
available source and documentation for TurboVision 2.0.

Note that no path information is stored in these archives.
Typically, the contents of INCLUDE.ZIP are to be placed in
\BCx\INCLUDE\TVISION; the contents of SOURCE.ZIP are to be
placed in \BCx\SOURCE\TVISION.  Also note that the source
includes some assembly language (*.ASM) files.  Successful
generation of the TurboVision library will require use of
Turbo Assembler to translate these source files into object
files.  DOCS.ZIP can be placed anywhere.


DISCLAIMER AND LIMITATION OF LIABILITY:
---------------------------------------
DISCLAIMER AND LIMITATION OF LIABILITY: Borland does not make or
give any representation or warranty with respect to the
usefulness or the efficiency of this software, it being
understood that the degree of success with which equipment,
software, modifications, and other materials can be applied to
data processing is dependent upon many factors, many of which
are not under Borland's control.  ACCORDINGLY, THIS SOFTWARE IS
PROVIDED 'AS IS' WITHOUT EXPRESS OR IMPLIED WARRANTIES,
INCLUDING NO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE, OR NONINFRINGEMENT.  THIS SOFTWARE IS
PROVIDED GRATUITOUSLY AND, ACCORDINGLY, BORLAND SHALL NOT BE
LIABLE UNDER ANY THEORY FOR ANY DAMAGES SUFFERED BY YOU OR ANY
USER OF THE SOFTWARE.  BORLAND WILL NOT SUPPORT THIS SOFTWARE
AND IS UNDER NO OBLIGATION TO ISSUE UPDATES TO THIS SOFTWARE.

WITHOUT LIMITING THE GENERALITY OF THE FOREGOING, NEITHER
BORLAND NOR ITS SUPPLIERS SHALL BE LIABLE FOR (a) INCIDENTAL,
CONSEQUENTIAL, SPECIAL OR INDIRECT DAMAGES OF ANY SORT, WHETHER
ARISING IN TORT, CONTRACT OR OTHERWISE, EVEN IF BORLAND HAS BEEN
INFORMED OF THE POSSIBILITY OF SUCH DAMAGES, OR (b) FOR ANY
CLAIM BY ANY OTHER PARTY.  SOME STATES DO NOT ALLOW THE
EXCLUSION OR LIMITATION OF INCIDENTAL OR CONSEQUENTIAL DAMAGES,
SO THIS LIMITATION AND EXCLUSION MAY NOT APPLY TO YOU.  Use,
duplication or disclosure by the Government is subject to
restrictions set forth in subparagraphs (a) through (d) of the
Commercial Computer-Restricted Rights clause at FAR 52.227-19
when applicable, or in subparagraph (c) (1) (ii) of the Rights
in Technical Data and Computer Software clause at DFARS
252.227-7013, and in similar clauses in the NASA AR Supplement.
Contractor / manufacturer is Borland International, Inc.,
100 Borland Way, Scotts Valley, CA 95066.
