
#include <stdio.h>
#include "externs.h"

/*************************************************************************/
/*                                                                       */
/* function to parse a string into individual tokens and return pointer  */
/* to the array and number of tokens                                     */
/*                                                                       */
/*************************************************************************/

int parse(char *tokens[])
{
 int i;              /* test */

 char *cp;           /* temperorary indexing for cmd_line */

 int token_counter=0;    /* token counter to zero  */

 cp=cmd_line;            /* get first character position in cmd_line */

 while (1)               /* loop until break out of loop */
 {
  while(isspace(*cp))    /* find a token*/
   cp++;

  if (*cp==NULL)
   break;        /* break out of loop when null encountered in cmd_line */

  tokens[token_counter]=cp++;   /* set pointer to token found */
  token_counter++;                 /* increment token counter    */

  while(!isspace(*cp) && (*cp)!=NULL)
   cp++;
 

  if (*cp==NULL)
   break;      /* break out of loop when null encountered in cmd_line */

  *cp=NULL;    /* append NULL  */
  cp++;

 } /* end while loop */

 return token_counter;  /* return number of  tokens */
}
