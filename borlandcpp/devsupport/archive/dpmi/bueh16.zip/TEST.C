#include <stdio.h>
#include <windows.h>

#pragma argsused
int main (int argc, char *argv[])
{
  GetFocus ();        // This one will be fixed up and handled by BUEH
  Yield ();           // This one will be fixed up and handled by BUEH
  GetMessageTime ();  // This one will be fixed up to an error routine.

  return 0;
}

#include "bueh.c"
