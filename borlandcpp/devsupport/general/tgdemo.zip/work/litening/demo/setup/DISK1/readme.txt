
        Borland C++ Development Suite with Design Tools Demo
        ====================================================

                             README.TXT
                             ----------


Type "setup.exe" to install the Borland C++ Development Suite with
Design Tools demo on your system. This will create the "Borland Demo"
group with the "Borland C++ Design Tools Demo" item. Double click on
this item to view the slides and demo.

An uninstall program is included in the "Borland Demo" Program Group
to remove the demo from your system.
