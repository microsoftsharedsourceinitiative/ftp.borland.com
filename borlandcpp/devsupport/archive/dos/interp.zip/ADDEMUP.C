








#include <stdio.h>
#include "externs.h"

/****** addemup function *******/

int addemup(int argc,char *argv[])
{
 int index;
 int total=0;
 int all_digits=1;

 if (argc>1 )       /* check if at least one argument  */
 {
  for(index=1;index<argc && all_digits;index++)
   total+=isnumber(argv[index],&all_digits);  /* check all arguments  */
                                              /* make sure all are    */
  if (!all_digits)
			  /* digit characters     */
   error(etable[1]);      /* if not all digits */
			  /* call error table  */
		          /* with proper message */
  else
   printf("= %d\n",total);   /* print total of all arguments */
 }
 else
  error(etable[6]);   /* no arguments */
                      /* call proper error message */



 return total;
}

#pragma -u

/**********************************************************/
/* string checking rountine                               */
/* char char_number[]: array of alphanumerical characters */
/*                     must be null terminated.           */
/* DESCRIPTION:					          */
/* search char_number for one occurence of a character    */
/* not in the range '0' to '9' and set flag to false      */
/* if all character in string are '0' to '9' then return  */
/* long integer of coverted string.                       */
/**********************************************************/

int isnumber(char char_number[],int *flag)
{
 int index=0;
 int is_number=1;
 int character;

 *flag=1;

 if (char_number[index]=='+'|| char_number[index]=='-') /* check for */
							/* leading sign */
  index++;
 while((character=char_number[index])!=NULL && *flag) /* loop until non digit */
 {                                                    /* found or until null  */
						      /* character found in string */
  if (isdigit(character))  /* if character is digit */                          
   index++;                /* get next character    */
  else
   *flag=0;                /* when character is not   */
 }                         /* digit set flag to false */
 if (*flag)
  is_number=atoi(char_number); /* convert only if flag is true */
                               /* ... all charaters are convertable */

 return is_number;      /* return converted number */
}
