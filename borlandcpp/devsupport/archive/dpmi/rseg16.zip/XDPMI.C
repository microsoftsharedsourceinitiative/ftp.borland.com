#include <stdio.h>
#include <stdlib.h>

#include <windows.h>
#include <dos.h>

#include "xdpmi.h"
	
void dpmi_error(unsigned short err_code, int fatality)
{
	fprintf(stderr, "DPMI error %hu\n", err_code);

        if (fatality)
                exit(fatality);
}


int dos_alloc(unsigned short sz, unsigned short *sel, unsigned short *seg)
{
        unsigned long rc = GlobalDosAlloc(sz);
        *sel = LOWORD(rc);
        *seg = HIWORD(rc);
        return 0;
}


int dos_free(unsigned short sel)
{
        return GlobalDosFree(sel);
}


int set_real_handler(unsigned char int_no, INT_FUNC int_func)
{
	unsigned seg = GetSelectorBase(FP_SEG((void *) int_func)) >> 4;

	_DX = FP_OFF(int_func);
	_CX = seg;
	_BL = int_no;
	_AX = 0x201;           /* set real mode handler */
	geninterrupt(0x31);

	return 0;
}

int sim_rm_intr(unsigned char int_no, struct register_data *r)
{
    /* probably should set the rest of register data first.  oh well.  */

	_ES = FP_SEG(r);
	_DI = FP_OFF(r);
	_BL = int_no;
	_AX = 0x300;           /* simulate real mode interrupt */
	geninterrupt(0x31);

	return (_FLAGS & 0x1) ? - _AX : 0;
}


int rm_proc_retf(REAL_FUNC rf, struct register_data *r)
{
        unsigned fn_seg = GetSelectorBase(FP_SEG(rf)) >> 4;
        r->rd_ip = FP_OFF(rf);
        r->rd_cs = fn_seg;

        if (! r->rd_ds)
                r->rd_ds = fn_seg;      /* hope this is right... */

        if (! r->rd_es)
                r->rd_es = fn_seg;

        _ES = FP_SEG(r);
        _DI = FP_OFF(r);
        _AX = 0x301;           /* call real-mode procedure, far return */
        geninterrupt(0x31);

        return (_FLAGS & 0x1) ? - _AX : 0;
}
