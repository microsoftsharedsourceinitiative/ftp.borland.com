
#include <stdio.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <errno.h>


#include "externs.h"


/**** view function ****/

int view(int argc,char *argv[])
{
 char character;
 int file_descrip;

 if(argc>1)                  /* check if at least on argument */

  if(-1<(file_descrip=open(argv[1],O_RDONLY | O_TEXT)))  /* try to open */
  {                                                      /* file        */
  int lines=0;

   while (read(file_descrip,&character,1))   /* read one character at */
   {                                         /* a time                */


    if ((char)character==RETURN)      /* count number of lines for */
     lines++;                         /* screen suspend            */

    putchar(character);

    if (lines==SCREEN_SIZE)
    {
     printf("hit any key to continue..."); /* hold for one screen full */
     getche();
     printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
     printf("                          ");
     printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
     lines=0;
    }
   }

   close(file_descrip);    /* close file */
  }
  else
   if (errno==ENOENT)   /* error with open of file */

    error(etable[0]); /* file not found error */
   else

    error(etable[4]); /* all other open errors */

 else
   error(etable[5]);     /* no arguments passed send proper */
                         /* error message */
 return 0;
}



