#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <windows.h>
#include <dos.h>

#include "xdpmi.h"
#include "real.h"

int main(void)
{
	unsigned short r_sel, r_seg;
	unsigned short rc;
	struct register_data r;
	unsigned *block;

	if ((rc = dos_alloc(sizeof(unsigned), &r_sel, &r_seg)) != 0)
		dpmi_error(-rc, 1);

	block = MK_FP(r_sel, 0);
        memset(block, -1, sizeof(unsigned));

        /* let the real-mode code store the allocated segment */
	memset(&r, 0, sizeof(r));
	r.rd_eax = r_seg;
        if ((rc = rm_proc_retf(stash_seg_Real, &r)) != 0)
		dpmi_error(-rc, 1);

        /* interrupt 0x79 is listed as "unused".  checking
           for a previous handler (and storing it) should
           probably happen first.
        */

	if ((rc = set_real_handler(0x79, do_it_Real)) != 0)
		dpmi_error(-rc, 1);

        /* check to see that it works */
        printf("Before calling the interrupt, the buffer holds 0x%X\n",
                        *block);
        memset(&r, 0, sizeof(r));
        r.rd_eax = 0xbeef;
	if ((rc = sim_rm_intr(0x79, &r)) != 0)
		dpmi_error(-rc, 1);

	printf("The value in the buffer now is 0x%X\n", *block);

        set_real_handler(0x79, (INT_FUNC) 0);
	dos_free(r_sel);

	return 0;
}


